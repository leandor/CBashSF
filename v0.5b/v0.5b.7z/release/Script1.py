

import wxversion
wxversion.select("2.8")
import wx, wx.html
import sys
import StringIO

from ctypes import *
Logger = CDLL("CBash.dll")
LogFunc = Logger.LoggingTest

class XPinst(wx.App):
    def __init__(self, redirect=False, filename=None):
        wx.App.__init__(self, redirect, filename)

    def OnInit(self):
        self.frame = wx.Frame(None, -1, title='Redirect Test', size=(620,450), style=wx.STAY_ON_TOP| wx.DEFAULT_FRAME_STYLE)

        panel = wx.Panel(self.frame, -1)

##        buffer = StringIO.StringIO()
##        sys.stdout=buffer
        print 'test'
        LogFunc("Testing LogFunc")
        self.frame.Show()
        return True

app = XPinst(True)
app.MainLoop()
