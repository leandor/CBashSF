from ctypes import *
import struct
import math
from os.path import exists

try:
    from bolt import GPath
    import bush
    import bosh
except:
    def GPath(obj):
        return obj

Logger = CDLL("CBash.dll")
LogFunc = Logger.SetLogging


def LoggingCB(testString):
    print testString
    return 0

LoggingCallback = CFUNCTYPE(c_int, c_char_p)(LoggingCB)

import wxversion
wxversion.select("2.8")
import wx, wx.html
import sys

class Frame(wx.Frame):
    def __init__(self, title):
        wx.Frame.__init__(self, None, title=title, pos=(150,150), size=(350,200))
        self.Bind(wx.EVT_CLOSE, self.OnClose)
        LogFunc(0, LoggingCallback, 0, 0)
        menuBar = wx.MenuBar()
        menu = wx.Menu()
        m_exit = menu.Append(wx.ID_EXIT, "E&xit\tAlt-X", "Close window and exit program.")
        self.Bind(wx.EVT_MENU, self.OnClose, m_exit)
        menuBar.Append(menu, "&File")

        self.statusbar = self.CreateStatusBar()

        panel = wx.Panel(self)
        box = wx.BoxSizer(wx.VERTICAL)

        m_text = wx.StaticText(panel, -1, "Hello World!")
        m_text.SetFont(wx.Font(14, wx.SWISS, wx.NORMAL, wx.BOLD))
        m_text.SetSize(m_text.GetBestSize())
        box.Add(m_text, 0, wx.ALL, 10)

        m_close = wx.Button(panel, wx.ID_CLOSE, "Close")
        m_close.Bind(wx.EVT_BUTTON, self.OnClose)
        box.Add(m_close, 0, wx.ALL, 10)

        m_test = wx.Button(panel, wx.ID_CLOSE, "Test")
        m_test.Bind(wx.EVT_BUTTON, self.OnTest)
        box.Add(m_test, 0, wx.ALL, 10)

        panel.SetSizer(box)
        panel.Layout()

    def OnTest(self, event):
        print "Testing"
        LogFunc(0, LoggingCallback, 10, 0xF0123456)

    def OnClose(self, event):
        self.Destroy()

def TestLogging():
    app = wx.App()
    top = Frame("<<project>>")
    top.Show()

    app.MainLoop()



TestLogging()
